//
//  JackSoftnauts.h
//  JackSoftnauts
//
//  Created by Jacek Kurbiel on 11/02/2020.
//  Copyright © 2020 Jacek Kurbiel. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for JackSoftnauts.
FOUNDATION_EXPORT double JackSoftnautsVersionNumber;

//! Project version string for JackSoftnauts.
FOUNDATION_EXPORT const unsigned char JackSoftnautsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JackSoftnauts/PublicHeader.h>


